#include <stdio.h>
#include <vector>
#include <algorithm>

#define MAXN 10050

using namespace std;

vector<int> adj[MAXN];

int N;
int popul[MAXN];
int DP[MAXN][2];

void fillTable(int par, int cur){
	int resultCurrentNotIncluded = 0;
	int resultCurrentIncluded = 0;

	for(int next : adj[cur]){
		if(next == par) continue;
		fillTable(cur, next);
		resultCurrentIncluded += DP[next][0];
		resultCurrentNotIncluded += max(DP[next][0], DP[next][1]);
	}

	DP[cur][0] = resultCurrentNotIncluded;
	DP[cur][1] = resultCurrentIncluded + popul[cur];
}

int main(){
	scanf("%d", &N);
	for(int i = 0; i < N; i++){
		scanf("%d", popul+i);
	}
	for(int i = 0,u,v; i < N-1; i++){
		scanf("%d%d", &u, &v);
		u--, v--;
		adj[u].push_back(v);
		adj[v].push_back(u);
	}

	fillTable(-1, 0);
	printf("%d\n", max(DP[0][0], DP[0][1]));
}