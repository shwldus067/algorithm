#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <vector>
#define MAXN 1050

int DP[MAXN][MAXN];

char s1[MAXN];
char s2[MAXN];

std::vector<char> answer;

void initialization(){
	for(int i = 0; i < MAXN; i++){
		for(int j = 0; j < MAXN; j++){
			DP[i][j] = -1;
		}
	}
}

int foo(int i, int j){
	if(i == -1 || j == -1) return 0;
	if(DP[i][j] != -1) return DP[i][j];
	int result = 0;
	if(s1[i] == s2[j]) result = std::max(result, foo(i-1, j-1) + 1);
	result = std::max(result, std::max(foo(i-1, j), foo(i, j-1)));
	return DP[i][j] = result;
}

void trace(int i, int j){
	if(i == -1 || j == -1) return;
	if(foo(i,j) == foo(i-1, j)){
		trace(i-1, j);
	}
	else if(foo(i,j) == foo(i, j-1)){
		trace(i, j-1);
	}
	else if(foo(i,j) == foo(i-1, j-1) + 1){
		answer.push_back(s1[i]);
		trace(i-1, j-1);
	}
}

int main(){
	initialization();
	scanf("%s", s1);
	scanf("%s", s2);

	printf("%d\n",foo(strlen(s1)-1, strlen(s2)-1));
	trace(strlen(s1)-1, strlen(s2)-1);

	for(auto rit = answer.rbegin(); rit != answer.rend(); rit++){ // print in reverse order
		printf("%c", *rit);
	}
	return 0;
}