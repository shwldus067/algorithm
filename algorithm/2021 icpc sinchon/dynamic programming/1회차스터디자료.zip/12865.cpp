#include <stdio.h>
#define INF 1234567890
int DP[150][100050];

int w[150], v[150];
int N, K;

int max(int a, int b){
	return (a>b)?a:b;
}

int foo(int i, int j){
	if(j < 0) return -INF;
	if(i < 0) return 0;
	return DP[i][j];
}

int main(){
	scanf("%d%d", &N, &K);
	for(int i = 0; i < N; i++){
		scanf("%d%d", w+i, v+i);
	}
	for(int i = 0; i < N; i++){
		for(int j = 0; j <= K; j++){
			DP[i][j] = max(foo(i-1, j), foo(i-1, j-w[i])+v[i]);
		}
	}
	printf("%d\n", DP[N-1][K]);
}