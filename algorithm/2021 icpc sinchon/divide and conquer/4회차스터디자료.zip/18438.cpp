#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MINV -1



char sa[7050];
char sb[7050];

int dp[2][7005];
int id[2][7005];

int solve(int ai, int aj, int bi, int bj, int print){
	if(aj-ai < 2) return 0;
	int amid = (ai+aj)/2;
	int cur = 1;
	dp[0][bi] = 0;
	bool flag = false;
	for(int i = ai; i <= aj; i++){
		cur = 1-cur;
		for(int j = bi; j <= bj; j++){
			if(i == ai && j == bi) continue;
			int le, up, di;

			// from left
			if(j == bi) le = MINV;
			else le = dp[cur][j-1];

			// from upward
			if(i == ai) up = MINV;
			else up = dp[1-cur][j];

			// from upper-left diagonal
			if(j == bi || i == ai) di = MINV;
			else di = dp[1-cur][j-1] + (sa[i]==sb[j]);
			
			if(i == amid){
				if(di >= le && di >= up){
					id[cur][j] = j;
					dp[cur][j] = di;
				}
				else if(le >= up && le >= di){
					id[cur][j] = id[cur][j-1];
					dp[cur][j] = le;
				}
				else{
					id[cur][j] = j;
					dp[cur][j] = up;
				}
				flag = true;
			}
			else if(flag){
				if(di >= le && di >= up){
					id[cur][j] = id[1-cur][j-1];
					dp[cur][j] = di;
				}
				else if(le >= up && le >= di){
					id[cur][j] = id[cur][j-1];
					dp[cur][j] = le;
				}
				else{
					id[cur][j] = id[1-cur][j];
					dp[cur][j] = up;
				}
			}
			else{
				if(di >= le && di >= up){
					dp[cur][j] = di;
				}
				else if(le >= up && le >= di){
					dp[cur][j] = le;
				}
				else{
					dp[cur][j] = up;
				}
			}
		}
	}
	int idx = id[cur][bj];
	if(print){
        printf("%d\n", dp[cur][bj]);
        if(dp[cur][bj] == 0) exit(0);
    }
	solve(ai, amid, bi, idx, 0);
	if(sa[amid]==sb[idx]) printf("%c", sa[amid]);
	solve(amid, aj, idx, bj, 0);
    return 0;
}

int main(){
	scanf("%s", sa+1);
	scanf("%s", sb+1);
	int la = strlen(sa+1);
	int lb = strlen(sb+1);
	sa[la+1] = '#'; // dummy charactor
	sa[la+2] = 0;
	sb[lb+1] = '@';
	sb[lb+2] = 0;
	la = strlen(sa+1), lb = strlen(sb+1);
	solve(0, la, 0, lb, 1);
	puts("");
}