#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <algorithm>
#include <random>

using namespace std;

int arr[1050][1050];
int brr[1050][1050];
int rv[1050];
int tv[1050];
int fv[1050];
int N;

int deterministic_square(){
	for(int i = 0; i < N; i++){
		for(int j = 0; j < N; j++){
			int tmp = 0;
			for(int k = 0; k < N; k++){
				tmp += arr[i][k]*arr[k][j];
			}
			if(tmp != brr[i][j]) return false;
		}
	}
	return true;
}

int randomized_square(){
	for(int i = 0; i < N; i++){
		tv[i] = 0;
		for(int j = 0; j < N; j++){
			tv[i] += arr[i][j]*rv[j];
		}
	}
	for(int i = 0; i < N; i++){
		fv[i] = 0;
		for(int j = 0; j < N; j++){
			fv[i] += arr[i][j]*tv[j];
		}
	}
	for(int i = 0; i < N; i++){
		int tmp = 0;
		for(int j = 0; j < N; j++){
			tmp += brr[i][j]*rv[j];
		}
		if(tmp != fv[i]) return false;
	}
	return true;
}

int main(){
	srand(time(NULL));
	default_random_engine generator;
	uniform_int_distribution<int> dec(0,100000);
	while(true){
		scanf("%d", &N);
		if(N == 0) return 0;
		for(int i = 0; i < N; i++){
			for(int j = 0; j < N; j++){
				scanf("%d", &arr[i][j]);
			}
		}
		for(int i = 0; i < N; i++){
			for(int j = 0; j < N; j++){
				scanf("%d", &brr[i][j]);
			}
		}
		if(N < 100){
			if(deterministic_square()) puts("YES");
			else puts("NO");
		}
		else{
			for(int i = 0; i < N; i++){
				rv[i] = dec(generator);
			}
			if(randomized_square()) puts("YES");
			else puts("NO");
		}
	}
}