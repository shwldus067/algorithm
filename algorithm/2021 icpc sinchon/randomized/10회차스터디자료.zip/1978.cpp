#include <stdio.h>
#include <random>
#include <time.h>

#define THRES 1000050
#define CNUM 20

using namespace std;
//long long int chk[CNUM] = {2LL,3LL,5LL,7LL,11LL,13LL,17LL,19LL,23LL,29LL,31LL,37LL};

default_random_engine generator;

long long int mult(long long int a, long long int b, long long int mod) {
   long long int cur = a, ret = 0LL;
   for (int i = 0; i < 61; i++) {
      if (b&(1LL << i)) {
         ret += cur; ret %= mod;
      }
      cur += cur; cur %= mod;
   }
   return ret % mod;
}

long long int pow(long long int x, long long int y, long long int mod){
	if(y == 0) return 1LL;
	if(y % 2 == 1) return mult(x, pow(x, y-1, mod), mod);
	long long int t = pow(x, y/2, mod);
	return mult(t, t, mod);
}

bool prime_chk(long long int N){
	if(N == 1) return false;
	if(N == 2 || N == 3) return true;
	if(N % 2 == 0) return false;

  	uniform_int_distribution<int> uD(2,N-1);
	long long int d = N - 1;
	long long int s = 0;
	while(d % 2 == 0){
		d /= 2;
		s++;
	}
	for(int i = 0; i < CNUM; i++){
		long long int a = uD(generator);
		long long int a_pow_d = pow(a, d, N);
		if(a_pow_d == 1) continue;
		bool flag = false;
		for(int j = 0; j < s; j++){
			if(a_pow_d == N - 1){
				flag = true;
				break;
			}
			a_pow_d = mult(a_pow_d, a_pow_d, N);
		}
		if(flag) continue;
		return false;
	}
	return true;
}

int main(){
	int N, ans = 0;
	scanf("%d", &N);
	srand(time(NULL));
	for(int i = 0, t; i < N; i++){
		scanf("%d", &t);
		if(prime_chk(t)) ans++;
	}

	printf("%d\n", ans);
}