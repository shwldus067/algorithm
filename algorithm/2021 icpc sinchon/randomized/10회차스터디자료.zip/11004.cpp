#include <stdio.h>
#include <time.h>
#include <random>
using namespace std;

int N, K;
int arr[5000050];

default_random_engine generator;

void swap(int i, int j){
	int t = arr[i];
	arr[i] = arr[j];
	arr[j] = t;
}

int Partition(int l, int r, int pidx){
	int pval = arr[pidx];
	swap(pidx, l);
	l--;
	while(true){
		do ++l; while (arr[l] < pval);
		do --r; while (arr[r] > pval);
		if(l >= r) return r+1;
		swap(l, r);
	}
	return r+1;
}

int QuickSelect(int l, int r, int k){
	if(r-l == 1) return arr[l];
  	uniform_int_distribution<int> selectPivot(l,r-1);
  	int pidx = selectPivot(generator);
  	pidx = Partition(l, r, pidx);

  	if(k < pidx) return QuickSelect(l, pidx, k);
  	else return QuickSelect(pidx, r, k);
}

int main(){
	scanf("%d%d", &N, &K);
	srand(time(NULL));
	for(int i = 0; i < N; i++) scanf("%d", arr+i);

	int ans = QuickSelect(0, N, K-1);
	printf("%d\n", ans);
}