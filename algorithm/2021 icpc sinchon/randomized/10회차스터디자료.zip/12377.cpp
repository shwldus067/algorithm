#include <stdio.h>
#include <algorithm>
#include <stdlib.h>
#include <time.h>
#include <random>
#define EPS 0.00001

using namespace std;

struct circle{
	int idx, rad;
	double x, y;
}C[10050];

int T;
int N;
int W, L;

bool cmp1(circle c1, circle c2){
	return c1.rad>c2.rad;
}

bool cmp2(circle c1, circle c2){
	return c1.idx < c2.idx;
}

double dist(double x1, double y1, double x2, double y2){
	return (x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)+EPS;
}


int main(){
	scanf("%d", &T);
	srand(time(NULL));
	default_random_engine generator;
	for(int tc = 1; tc <= T; tc++){
		printf("Case #%d:", tc);
		scanf("%d%d%d", &N, &W, &L);
  		uniform_int_distribution<int> d_W(0,W-1);
  		uniform_int_distribution<int> d_L(0,L-1);
  		uniform_int_distribution<int> dec(0,99);
		for(int i = 0, r; i < N; i++){
			scanf("%d", &r);
			C[i].idx = i;
			C[i].rad = r;
		}
		sort(C, C+N, cmp1);
		C[0].x = 0;
		C[0].y = 0;
		for(int i = 1; i < N; i++){
			while(true){
				double tx = d_W(generator)+dec(generator)/100.0;
				double ty = d_L(generator)+dec(generator)/100.0;
				bool chk = true;
				for(int j = 0; j < i; j++){
					if(dist(C[j].x, C[j].y, tx, ty) < (double)(C[i].rad+C[j].rad)*(C[i].rad+C[j].rad)){
						chk = false;
						break;
					}
				}

				if(chk){
					C[i].x = tx;
					C[i].y = ty;
					break;
				}
			}
		}
		sort(C, C+N, cmp2);
		for(int i = 0; i < N; i++){
			printf(" %.2f %.2f", C[i].x, C[i].y);
		}
		puts("");
	}
}